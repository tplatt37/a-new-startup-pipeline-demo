#!/bin/bash

#
# Convenient way to create an ECR Private repo, build, tag, and push image
#

# Get the current AWS REGION
REGION=${AWS_DEFAULT_REGION:-$(aws configure get default.region)}

# Get the current AWS ACCOUNT ID
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# Create an ecr private repository named "a-new-startup"
aws ecr create-repository --repository-name a-new-startup --region $REGION

# Get logged in so we can PUSH later.
aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com

VERSION=v1.0.0

docker build -t a-new-startup .

docker tag a-new-startup:latest $AWS_ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/a-new-startup:$VERSION

docker push $AWS_ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/a-new-startup:$VERSION
