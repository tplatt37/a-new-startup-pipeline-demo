#!/bin/bash

# Install stress
# We can invoke this via SSM to simulate load for autoscaling demo.
#
yum -y install stress

# Install apache
yum -y install httpd

# Set up proxy for Node server
cat <<EOT >> /etc/httpd/conf/httpd.conf
LoadModule proxy_module modules/mod_proxy.so
LoadModule proxy_http_module modules/mod_proxy_http.so

ProxyRequests Off
ProxyPass / http://localhost:3000/
ProxyPassReverse / http://localhost:3000/

<Location "/">
  Order allow,deny
  Allow from all
</Location>
EOT
