#!/bin/bash

# Very simple validation - is anything listening on port 3000?
curl http://localhost:3000