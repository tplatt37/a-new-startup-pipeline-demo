#!/bin/bash

# Give it a moment to start...
sleep 5

# Very simple validation - is anything listening on port 3000?
curl http://localhost:3000