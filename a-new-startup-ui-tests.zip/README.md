
docker build -t ui-tests-a-new-startup --build-arg arg_url=https://a-new-startup-test.awstrainer.com . 

