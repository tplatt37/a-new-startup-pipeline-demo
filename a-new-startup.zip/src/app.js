var os = require("os");
var hostname = os.hostname();
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');

var fs = require('fs');
var util = require('util');
var log_file = fs.createWriteStream(__dirname + '/debug.log', {flags : 'w'});
var log_stdout = process.stdout;

// Capture console.log output in a local file debug.log - makes it easier to troubleshoot load balanced instances
console.log = function(d) { //
  log_file.write(util.format(d) + '\n');
  log_stdout.write(util.format(d) + '\n');
};

// FOR XRAY - THERE ARE SEVERAL LINES TO UNCOMMENT
// UNCOMMENT FOR XRAY
//var AWSXRay = require('aws-xray-sdk');

var AWS = require('aws-sdk');

// UNCOMMENT FOR XRAY - ENSURES CAPTURE OF AWS SDK CALLS TO DDB, SNS
//var AWS = AWSXRay.captureAWS(require('aws-sdk'));

AWS.config.region = process.env.REGION

var sns = new AWS.SNS();
var ddb = new AWS.DynamoDB();

var ddbTable =  process.env.APP_TABLE_NAME;
// This is an ARN !
var snsTopic =  process.env.APP_TOPIC_ARN;
console.log("Using ddbTable=" + process.env.APP_TABLE_NAME )
console.log("using snsTopic=" + process.env.APP_TOPIC_ARN )

var app = express();

//UNCOMMENT FOR XRAY
//app.use(AWSXRay.express.openSegment('a-new-startup-segment'));

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(bodyParser.urlencoded({extended:false}));

app.use('/static', express.static(path.join(__dirname, 'static')))

app.get('/', function(req, res) {
    res.render('index', {
        static_path: 'static',
        theme: process.env.THEME || 'flatly',
        flask_debug: process.env.FLASK_DEBUG || 'false',
        hostinfo: hostname,
        ddb_table: process.env.APP_TABLE_NAME || 'Not set!'
    });
});

app.post('/signup', function(req, res) {
    var item = {
        'email': {'S': req.body.email},
        'name': {'S': req.body.name},
        'preview': {'S': req.body.previewAccess},
        'theme': {'S': req.body.theme}
    };

    console.log(item);
    //UNCOMMENT FOR X-RAY
    //var seg = AWSXRay.getSegment();
    //// Annotations are indexed - you can filter with: annotations.email = "test@pctech2000.com"
    //seg.addAnnotation('email', req.body.email);
    //seg.addAnnotation('name', req.body.name);
    //seg.addAnnotation('preview', req.body.previewAccess);
    //seg.addAnnotation('theme', req.body.theme);
    
    // Metadata is not indexed.
    //seg.addMetadata('email', req.body.email, "optional-namespace");
    //seg.addMetadata('name', req.body.name, "optional-namespace");
    //seg.addMetadata('preview', req.body.previewAccess, "optional-namespace");
    //seg.addMetadata('theme', req.body.theme, "optional-namespace");

    ddb.putItem({
        'TableName': ddbTable,
        'Item': item,
        'Expected': { email: { Exists: false } }        
    }, function(err, data) {
        if (err) {
            var returnStatus = 500;

            if (err.code === 'ConditionalCheckFailedException') {
                returnStatus = 409;
            }

            res.status(returnStatus).end();
            console.log('DDB Error: ' + err);
        } else {
            sns.publish({
                'Message': 'Name: ' + req.body.name + "\r\nEmail: " + req.body.email 
                                    + "\r\nPreviewAccess: " + req.body.previewAccess 
                                    + "\r\nTheme: " + req.body.theme,
                'Subject': 'New user sign up!!!',
                'TopicArn': snsTopic
            }, function(err, data) {
                if (err) {
                    res.status(500).end();
                    console.log('SNS Error: ' + err);
                } else {
                    res.status(201).end();
                }
            });            
        }
    });
});

// UNCOMMENT FOR XRAY
//app.use(AWSXRay.express.closeSegment());

module.exports = app;